/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Minh Nghia
 */
public class Gift {
    String codeGift;
    int value;
    long time;

    public Gift() {
    }

    public Gift(String codeGift, int value, long time) {
        this.codeGift = codeGift;
        this.value = value;
        this.time = time;
    }

    public String getCodeGift() {
        return codeGift;
    }

    public void setCodeGift(String codeGift) {
        this.codeGift = codeGift;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

   
    
}
