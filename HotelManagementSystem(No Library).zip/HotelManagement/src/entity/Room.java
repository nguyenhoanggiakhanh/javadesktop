/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Minh Nghia
 */
public class Room {

    private String RoomNo;
    private int bed_number;
    private boolean Tv;
    private boolean Wifi;
    private boolean ari_con;
    private boolean Minibar;
    private String room_class;

    public Room() {
    }

    public Room(String RoomNo, int bed_number, boolean Tv, boolean Wifi, boolean ari_con, boolean Minibar, String room_class) {
        this.RoomNo = RoomNo;
        this.bed_number = bed_number;
        this.Tv = Tv;
        this.Wifi = Wifi;
        this.ari_con = ari_con;
        this.Minibar = Minibar;
        this.room_class = room_class;
    }

    public String getRoomNo() {
        return RoomNo;
    }

    public void setRoomNo(String RoomNo) {
        this.RoomNo = RoomNo;
    }

    public int getBed_number() {
        return bed_number;
    }

    public void setBed_number(int bed_number) {
        this.bed_number = bed_number;
    }

    public boolean isTv() {
        return Tv;
    }

    public void setTv(boolean Tv) {
        this.Tv = Tv;
    }

    public boolean isWifi() {
        return Wifi;
    }

    public void setWifi(boolean Wifi) {
        this.Wifi = Wifi;
    }

    public boolean isAri_con() {
        return ari_con;
    }

    public void setAri_con(boolean ari_con) {
        this.ari_con = ari_con;
    }

    public boolean isMinibar() {
        return Minibar;
    }

    public void setMinibar(boolean Minibar) {
        this.Minibar = Minibar;
    }

    public String getRoom_class() {
        return room_class;
    }

    public void setRoom_class(String room_class) {
        this.room_class = room_class;
    }  
}
