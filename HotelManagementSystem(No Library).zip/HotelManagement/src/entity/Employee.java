/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Minh Nghia
 */
public class Employee {

    private String Employee_ID;
    private String fullname;
    private String position;
    private int Salary;
    private String Birthday;
    private String Gender;
    private String Note;

    public Employee() {
    }

    public Employee(String Employee_ID, String fullname, String position, int Salary, String Birthday, String Gender, String Note) {
        this.Employee_ID = Employee_ID;
        this.fullname = fullname;
        this.position = position;
        this.Salary = Salary;
        this.Birthday = Birthday;
        this.Gender = Gender;
        this.Note = Note;
    }

    public String getEmployee_ID() {
        return Employee_ID;
    }

    public void setEmployee_ID(String Employee_ID) {
        this.Employee_ID = Employee_ID;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public int getSalary() {
        return Salary;
    }

    public void setSalary(int Salary) {
        this.Salary = Salary;
    }

    public String getBirthday() {
        return Birthday;
    }

    public void setBirthday(String Birthday) {
        this.Birthday = Birthday;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getNote() {
        return Note;
    }

    public void setNote(String Note) {
        this.Note = Note;
    }

  
}
