/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Minh Nghia
 */
public class Position {
    private int ID;
    private String namePosition;

    public Position() {
    }

    public Position(int ID, String namePosition) {
        this.ID = ID;
        this.namePosition = namePosition;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNamePosition() {
        return namePosition;
    }

    public void setNamePosition(String namePosition) {
        this.namePosition = namePosition;
    }
    
}
