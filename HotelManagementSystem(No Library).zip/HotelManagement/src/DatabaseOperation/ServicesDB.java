/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseOperation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import entity.Services;

/**
 *
 * @author Minh Nghia
 */
public class ServicesDB {

    Connection conn;
    PreparedStatement st = null;
    ResultSet rs = null;

    public ServicesDB() {
        this.conn = DataBaseConnection.connectTODB();
    }

    public boolean InsertService(Services sv) {
        try {
            st = conn.prepareStatement("INSERT INTO `service`(`IDService`, `name`, `price`) VALUES (?,?,?)");
            st.setString(1, sv.getIDService());
            st.setString(2, sv.getName());
            st.setString(3, sv.getPrice());
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully inserted new Service");
                return true;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ID existed");
        }
        return false;
    }

    public boolean UpdateService(Services sv) {
        try {
            st = conn.prepareStatement("UPDATE `service` SET `name`=?,`price`=? WHERE `IDService`=?");
            st.setString(3, sv.getIDService());
            st.setString(1, sv.getName());
            st.setString(2, sv.getPrice());
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "successfully Update Service");
                return true;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "UpdateService Failed");
        }
        return false;
    }

    public void deleleService(String ID) {
        try {
            st = conn.prepareStatement("DELETE FROM `service` WHERE `IDService`=? ");
            st.setString(1, ID);
            if (st.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Deleted Service");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicesDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public ResultSet getAllServices() {
        try {
            st = conn.prepareStatement("SELECT * FROM `service` ORDER BY ID ASC");
            rs = st.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(ServicesDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }

}
