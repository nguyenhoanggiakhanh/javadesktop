/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DatabaseOperation;

import entity.Order;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Minh Nghia
 */
public class OrderDB {

    Connection conn;
    PreparedStatement st = null;
    ResultSet rs = null;

    public void InsertOrderitem(Order order) {
        try {
            conn = DataBaseConnection.connectTODB();
            st = conn.prepareStatement("INSERT INTO `orderitem`(`RoomNo`, `nameItem`, `Price`, `Quantity`, `Total`) VALUES (?,?,?,?,?)");
            st.setString(1, order.getRoomNo());
            st.setString(2, order.getNameItem());
            st.setString(3, String.valueOf(order.getPrice()));
            st.setString(4, String.valueOf(order.getQuantity()));
            st.setString(5, String.valueOf(order.getTotal()));
            st.execute();

            JOptionPane.showMessageDialog(null, "successfully inserted a new Order");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.toString() + "\n" + "Order Failed");
        }
    }
}
